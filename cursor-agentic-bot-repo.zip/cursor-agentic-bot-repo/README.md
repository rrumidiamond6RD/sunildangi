# Cursor Agentic Automation Bot

A GitHub-ready starter repository for building an **agentic automation bot** that can receive a task, break it into steps, move between multiple browser tabs/pages, execute supported actions, keep an audit log, and optionally create GitHub commits/issues/PRs.

This repo is designed to be opened directly in **Cursor** and extended by a Grok/Cursor coding agent.

## What it does

- Accepts a task from CLI or JSON.
- Converts the task into a structured plan.
- Executes steps through modular tools.
- Supports multi-tab browser automation through Playwright.
- Supports human approval before high-impact/write actions.
- Produces structured run logs.
- Includes a GitHub Actions workflow for type-check/build.
- Keeps the LLM provider abstract so you can plug in Grok or another model.

## Architecture

```text
User task
   ↓
Task parser
   ↓
Planner / Agent loop
   ↓
Tool router
   ├── Browser tool (multi-tab)
   ├── GitHub tool
   ├── File/tool adapters
   └── Approval gate
   ↓
Execution log + result
```

## Quick start

```bash
npm install
cp .env.example .env
npm run dev
```

Run a task:

```bash
npm run task -- "Open example.com in one tab, open github.com in another tab, then report the titles"
```

## Cursor setup

1. Upload this repository to GitHub.
2. Open the repository in Cursor.
3. Connect Cursor/Grok to the GitHub repository.
4. Ask the coding agent to implement new adapters inside `src/` rather than modifying the whole architecture.
5. Keep secrets in `.env` or GitHub Actions secrets. Never commit tokens.

## Main extension points

### 1. Connect Grok / your model

Implement the provider call in:

`src/agent/provider.ts`

The provider must return a structured plan matching `AgentPlanSchema`.

### 2. Add website-specific automation

Add actions in:

`src/browser/browserTool.ts`

or create adapters like:

```text
src/browser/adapters/shopify.ts
src/browser/adapters/wordpress.ts
src/browser/adapters/internalAdmin.ts
```

### 3. Add GitHub writes

Use `src/github/githubTool.ts` as the safe boundary for creating issues, branches, commits, or pull requests.

### 4. Add approval rules

Edit:

`config/policy.json`

By default, destructive or external-write operations should require approval.

## Important safety rule

The bot should not blindly execute irreversible operations. Keep approval enabled for actions such as publishing, sending, deleting, purchasing, modifying production data, or changing external accounts.

## Example task JSON

See `examples/task.json`.

## Repository structure

```text
.github/workflows/ci.yml
config/policy.json
docs/ARCHITECTURE.md
examples/task.json
src/
  index.ts
  cli.ts
  agent/
    orchestrator.ts
    planner.ts
    provider.ts
    schemas.ts
  browser/
    browserTool.ts
    tabManager.ts
  github/
    githubTool.ts
  tasks/
    taskRunner.ts
  utils/
    approvals.ts
    logger.ts
```

## Next recommended upgrades

- Real Grok API integration.
- Persistent job queue (Redis/BullMQ).
- Browserbase/Steel/remote browser integration.
- Screenshot-based validation.
- Retry/recovery policy.
- Per-site adapters.
- GitHub App authentication instead of personal tokens.
- Database-backed run history.
- Web dashboard for task submission and approvals.
