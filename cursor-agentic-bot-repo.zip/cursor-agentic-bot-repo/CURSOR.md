# Cursor Agent Instructions

You are working inside an agentic automation repository.

## Goals

1. Preserve the modular architecture.
2. Add new capabilities as tools/adapters instead of hardcoding workflows.
3. Validate every model-produced plan before execution.
4. Require approval for irreversible or externally visible write actions.
5. Never commit API keys, cookies, passwords, or browser session secrets.
6. Prefer small pull requests with tests.

## When implementing a new automation

- Define the task outcome.
- Identify the external systems involved.
- Add or extend a dedicated adapter.
- Add structured actions with typed arguments.
- Add validation and errors.
- Add approval requirements for write actions.
- Add an example task.
- Update README/docs.

## Browser automation

Use stable selectors and explicit waits. Do not rely on fragile screen coordinates unless no semantic selector exists.

## GitHub automation

Use branches and pull requests for code changes. Avoid directly mutating the default branch from automated workflows.
