# Architecture

## Agent loop

The orchestrator receives a user task and asks the planner for a structured plan. Each plan step is routed to a tool.

Each step contains:

- `id`
- `tool`
- `action`
- `args`
- `requiresApproval`

The orchestrator executes steps sequentially and stores outputs. A later upgrade can add dependency graphs and parallel execution.

## Browser tabs

`TabManager` assigns a stable logical name to every page, for example:

- `research`
- `github`
- `admin`

The agent can open a new tab, switch by logical name, navigate, inspect text, click elements, type text, and read the page title.

## Provider abstraction

`provider.ts` deliberately contains a mock implementation. This prevents the repository from being tied to one vendor. Replace the mock with Grok or the model API that your Cursor workflow uses.

## Approval boundary

High-impact writes should be intercepted before execution. In development the repository uses an interactive CLI approval gate. In production replace this with a dashboard, Slack approval, or signed job approval.
