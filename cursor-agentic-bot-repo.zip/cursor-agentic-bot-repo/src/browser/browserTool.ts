import { TabManager } from "./tabManager.js";

export class BrowserTool {
  readonly tabs = new TabManager();

  async start() {
    await this.tabs.start();
  }

  async execute(action: string, args: Record<string, unknown>): Promise<unknown> {
    switch (action) {
      case "open_tab": {
        const name = String(args.name);
        const url = String(args.url);
        await this.tabs.open(name, url);
        return { name, url };
      }
      case "navigate": {
        const page = this.tabs.get(String(args.tab));
        await page.goto(String(args.url), { waitUntil: "domcontentloaded" });
        return { url: page.url() };
      }
      case "title": {
        return { title: await this.tabs.get(String(args.tab)).title() };
      }
      case "read_text": {
        const page = this.tabs.get(String(args.tab));
        const selector = args.selector ? String(args.selector) : "body";
        return { text: await page.locator(selector).innerText() };
      }
      case "click": {
        const page = this.tabs.get(String(args.tab));
        await page.locator(String(args.selector)).click();
        return { ok: true };
      }
      case "type": {
        const page = this.tabs.get(String(args.tab));
        await page.locator(String(args.selector)).fill(String(args.text));
        return { ok: true };
      }
      default:
        throw new Error(`Unsupported browser action: ${action}`);
    }
  }

  async close() {
    await this.tabs.close();
  }
}
