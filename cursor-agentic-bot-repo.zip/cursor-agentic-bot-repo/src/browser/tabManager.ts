import type { Browser, BrowserContext, Page } from "playwright";
import { chromium } from "playwright";

export class TabManager {
  private browser?: Browser;
  private context?: BrowserContext;
  private tabs = new Map<string, Page>();

  async start(): Promise<void> {
    this.browser = await chromium.launch({
      headless: process.env.HEADLESS === "true"
    });

    this.context = await this.browser.newContext(
      process.env.BROWSER_STORAGE_STATE
        ? { storageState: process.env.BROWSER_STORAGE_STATE }
        : undefined
    );
  }

  async open(name: string, url: string): Promise<Page> {
    if (!this.context) throw new Error("Browser not started");
    const page = await this.context.newPage();
    await page.goto(url, { waitUntil: "domcontentloaded" });
    this.tabs.set(name, page);
    return page;
  }

  get(name: string): Page {
    const page = this.tabs.get(name);
    if (!page) throw new Error(`Unknown tab: ${name}`);
    return page;
  }

  async close(): Promise<void> {
    await this.browser?.close();
  }
}
