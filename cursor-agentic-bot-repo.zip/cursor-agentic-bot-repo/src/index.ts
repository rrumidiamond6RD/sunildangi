import "dotenv/config";
import { runTask } from "./tasks/taskRunner.js";

const goal = process.env.DEFAULT_TASK ?? "Verify the agent repository boots correctly";
const output = await runTask(goal);
console.log(JSON.stringify(output, null, 2));
