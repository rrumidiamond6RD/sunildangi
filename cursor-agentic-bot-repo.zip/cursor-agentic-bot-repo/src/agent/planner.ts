import { AgentPlanSchema, type AgentPlan } from "./schemas.js";
import { createPlanFromModel } from "./provider.js";

export async function planTask(goal: string): Promise<AgentPlan> {
  const rawPlan = await createPlanFromModel(goal);
  return AgentPlanSchema.parse(rawPlan);
}
