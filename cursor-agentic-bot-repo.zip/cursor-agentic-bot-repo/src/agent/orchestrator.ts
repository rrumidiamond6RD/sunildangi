import type { AgentPlan, AgentStep } from "./schemas.js";
import { BrowserTool } from "../browser/browserTool.js";
import { GitHubTool } from "../github/githubTool.js";
import { requestApproval } from "../utils/approvals.js";
import { log } from "../utils/logger.js";

export class Orchestrator {
  private browser = new BrowserTool();
  private github = new GitHubTool();
  private browserStarted = false;

  async run(plan: AgentPlan) {
    const results: Array<{ step: AgentStep; result?: unknown; error?: string }> = [];

    try {
      for (const step of plan.steps) {
        log({ stepId: step.id, tool: step.tool, action: step.action, status: "started" });

        if (step.requiresApproval) {
          const approved = await requestApproval(`${step.tool}.${step.action} ${JSON.stringify(step.args)}`);
          if (!approved) {
            log({ stepId: step.id, tool: step.tool, action: step.action, status: "skipped" });
            results.push({ step, error: "Approval denied" });
            continue;
          }
        }

        try {
          const result = await this.executeStep(step);
          results.push({ step, result });
          log({ stepId: step.id, tool: step.tool, action: step.action, status: "completed", details: result });
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          results.push({ step, error: message });
          log({ stepId: step.id, tool: step.tool, action: step.action, status: "failed", details: message });
          break;
        }
      }
    } finally {
      if (this.browserStarted) await this.browser.close();
    }

    return results;
  }

  private async executeStep(step: AgentStep): Promise<unknown> {
    if (step.tool === "system") {
      if (step.action === "echo") return step.args;
      throw new Error(`Unsupported system action: ${step.action}`);
    }

    if (step.tool === "browser") {
      if (!this.browserStarted) {
        await this.browser.start();
        this.browserStarted = true;
      }
      return this.browser.execute(step.action, step.args);
    }

    if (step.tool === "github") {
      return this.github.execute(step.action, step.args);
    }

    throw new Error(`Unsupported tool: ${step.tool}`);
  }
}
