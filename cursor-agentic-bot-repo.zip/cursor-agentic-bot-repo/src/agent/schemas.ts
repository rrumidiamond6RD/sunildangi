import { z } from "zod";

export const AgentStepSchema = z.object({
  id: z.string(),
  tool: z.enum(["browser", "github", "system"]),
  action: z.string(),
  args: z.record(z.unknown()).default({}),
  requiresApproval: z.boolean().default(false)
});

export const AgentPlanSchema = z.object({
  objective: z.string(),
  steps: z.array(AgentStepSchema).min(1)
});

export type AgentStep = z.infer<typeof AgentStepSchema>;
export type AgentPlan = z.infer<typeof AgentPlanSchema>;
