import type { AgentPlan } from "./schemas.js";

/**
 * Replace this mock with Grok or your preferred model API.
 * Keep the output structured and validate it with AgentPlanSchema.
 */
export async function createPlanFromModel(goal: string): Promise<AgentPlan> {
  return {
    objective: goal,
    steps: [
      {
        id: "step-1",
        tool: "system",
        action: "echo",
        args: { message: `No live model provider configured. Goal received: ${goal}` },
        requiresApproval: false
      }
    ]
  };
}
