export class GitHubTool {
  async execute(action: string, args: Record<string, unknown>): Promise<unknown> {
    const token = process.env.GITHUB_TOKEN;
    const owner = String(args.owner ?? process.env.GITHUB_OWNER ?? "");
    const repo = String(args.repo ?? process.env.GITHUB_REPO ?? "");

    if (!token) throw new Error("GITHUB_TOKEN is not configured");
    if (!owner || !repo) throw new Error("GitHub owner/repo not configured");

    switch (action) {
      case "issue_create": {
        return this.request(`/repos/${owner}/${repo}/issues`, "POST", {
          title: String(args.title),
          body: String(args.body ?? "")
        });
      }
      default:
        throw new Error(`Unsupported GitHub action: ${action}`);
    }
  }

  private async request(path: string, method: string, body?: unknown) {
    const response = await fetch(`https://api.github.com${path}`, {
      method,
      headers: {
        Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "Content-Type": "application/json"
      },
      body: body ? JSON.stringify(body) : undefined
    });

    if (!response.ok) {
      throw new Error(`GitHub API error ${response.status}: ${await response.text()}`);
    }

    return response.json();
  }
}
