export type RunLog = {
  timestamp: string;
  stepId: string;
  tool: string;
  action: string;
  status: "started" | "completed" | "failed" | "skipped";
  details?: unknown;
};

export function log(entry: Omit<RunLog, "timestamp">): RunLog {
  const full = { timestamp: new Date().toISOString(), ...entry } satisfies RunLog;
  console.log(JSON.stringify(full));
  return full;
}
