import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";

export async function requestApproval(description: string): Promise<boolean> {
  if (process.env.REQUIRE_APPROVAL_FOR_WRITES === "false") return true;

  if (!process.stdin.isTTY) {
    console.warn(`Approval required but no interactive terminal is available: ${description}`);
    return false;
  }

  const rl = readline.createInterface({ input, output });
  const answer = await rl.question(`Approve action? ${description} [y/N] `);
  rl.close();
  return ["y", "yes"].includes(answer.trim().toLowerCase());
}
