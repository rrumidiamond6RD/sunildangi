import "dotenv/config";
import { runTask } from "./tasks/taskRunner.js";

const goal = process.argv.slice(2).join(" ").trim();
if (!goal) {
  console.error('Usage: npm run task -- "your task"');
  process.exit(1);
}

const output = await runTask(goal);
console.log(JSON.stringify(output, null, 2));
