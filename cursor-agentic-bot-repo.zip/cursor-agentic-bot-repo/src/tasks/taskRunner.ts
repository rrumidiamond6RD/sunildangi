import { planTask } from "../agent/planner.js";
import { Orchestrator } from "../agent/orchestrator.js";

export async function runTask(goal: string) {
  const plan = await planTask(goal);
  const orchestrator = new Orchestrator();
  const results = await orchestrator.run(plan);
  return { plan, results };
}
